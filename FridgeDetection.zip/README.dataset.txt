# FridgeDetection > resized640x640_aug3x
https://universe.roboflow.com/myproject-ko746/fridgedetection

Provided by a Roboflow user
License: CC BY 4.0

